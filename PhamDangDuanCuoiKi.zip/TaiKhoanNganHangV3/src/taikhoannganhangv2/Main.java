package phamdangduan;

import data.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        QuanLyPhongTro quanLyPhongTro = new QuanLyPhongTro();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            // Hiển thị menu
            System.out.println("\n=== Quản Lý Dãy Trọ ===");
            System.out.println("1. Thêm khách hàng");
            System.out.println("2. Thêm phòng");
            System.out.println("3. Thêm hợp đồng");
            System.out.println("4. Hiển thị danh sách khách hàng");
            System.out.println("5. Hiển thị danh sách phòng");
            System.out.println("6. Hiển thị danh sách hợp đồng");
            System.out.println("7. Xóa phòng");
            System.out.println("8. Xóa hợp đồng");
            System.out.println("9. Sửa thông tin khách hàng");
            System.out.println("0. Thoát");
            System.out.print("Nhập lựa chọn của bạn: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Đọc ký tự xuống dòng sau khi nhập số

            switch (choice) {
                case 1:
                    // Thêm khách hàng
                    themKhachHang(quanLyPhongTro, scanner);
                    break;

                case 2:
                    // Thêm phòng
                    themPhong(quanLyPhongTro, scanner);
                    break;

                case 3:
                    // Thêm hợp đồng
                    themHopDong(quanLyPhongTro, scanner);
                    break;

                case 4:
                    // Hiển thị danh sách khách hàng
                    System.out.println("\n=== Danh Sách Khách Hàng ===");
                    quanLyPhongTro.hienThiDanhSachKhachHang();
                    break;

                case 5:
                    // Hiển thị danh sách phòng
                    System.out.println("\n=== Danh Sách Phòng ===");
                    quanLyPhongTro.hienThiDanhSachPhong();
                    break;

                case 6:
                    // Hiển thị danh sách hợp đồng
                    System.out.println("\n=== Danh Sách Hợp Đồng ===");
                    quanLyPhongTro.hienThiDanhSachHopDong();
                    break;

                case 7:
                    // Xóa phòng
                    System.out.print("Nhập mã phòng cần xóa: ");
                    String maPhongXoa = scanner.nextLine();
                    quanLyPhongTro.xoaPhong(maPhongXoa);
                    System.out.println("Đã xóa phòng thành công!");
                    break;

                case 8:
                    // Xóa hợp đồng
                    System.out.print("Nhập mã hợp đồng cần xóa: ");
                    String maHd = scanner.nextLine();
                    quanLyPhongTro.xoaHD(maHd);
                    System.out.println("Đã xóa hợp đồng thành công!");
                    break;

                case 9:
                    // Sửa thông tin khách hàng
                    suaThongTinKhachHang(quanLyPhongTro, scanner);
                    break;

                case 0:
                    System.out.println("Đã thoát chương trình.");
                    break;

                default:
                    System.out.println("Lựa chọn không hợp lệ!");
            }
        } while (choice != 0);

        scanner.close();
    }

    // Phương thức để thêm khách hàng
    private static void themKhachHang(QuanLyPhongTro quanLyPhongTro, Scanner scanner) {
        System.out.print("Nhập mã khách hàng: ");
        String maKhachHang = scanner.nextLine();
        System.out.print("Nhập tên khách hàng: ");
        String tenKhachHang = scanner.nextLine();
        System.out.print("Nhập số điện thoại: ");
        String soDienThoai = scanner.nextLine();
        System.out.print("Nhập email: ");
        String email = scanner.nextLine();
        quanLyPhongTro.themKhachHang(new KhachHang(maKhachHang, tenKhachHang, soDienThoai, email));
        System.out.println("Đã thêm khách hàng thành công!");
    }

    // Phương thức để thêm phòng
    private static void themPhong(QuanLyPhongTro quanLyPhongTro, Scanner scanner) {
        System.out.print("Nhập mã phòng: ");
        String maPhong = scanner.nextLine();
        System.out.print("Nhập tên phòng: ");
        String tenPhong = scanner.nextLine();
        System.out.print("Nhập giá phòng: ");
        double giaPhong = scanner.nextDouble();
        scanner.nextLine(); // Đọc ký tự xuống dòng
        System.out.print("Nhập loại phòng (1 - Phòng Thường, 2 - Phòng VIP): ");
        int loaiPhong = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nhập mô tả: ");
        String moTa = scanner.nextLine();

        if (loaiPhong == 1) {
            // Thêm Phòng Thường
            System.out.print("Nhập tiền điện cho phòng Thường: ");
            double tienDien = scanner.nextDouble();
            System.out.print("Nhập tiền nước cho phòng Thường: ");
            double tienNuoc = scanner.nextDouble();
            quanLyPhongTro.themPhong(new PhongThuong(tienNuoc, tienDien, giaPhong, tenPhong, maPhong, moTa));
        } else if (loaiPhong == 2) {
            // Thêm Phòng VIP
            System.out.print("Nhập tiền điện cho phòng VIP: ");
            double tienDien = scanner.nextDouble();
            System.out.print("Nhập tiền nước cho phòng VIP: ");
            double tienNuoc = scanner.nextDouble();
            scanner.nextLine(); // Đọc ký tự xuống dòng
            quanLyPhongTro.themPhong(new PhongVip(tienNuoc, tienDien, giaPhong, tenPhong, maPhong, "VIP"));
        } else {
            System.out.println("Loại phòng không hợp lệ!");
        }
        System.out.println("Đã thêm phòng thành công!");
    }

    // Phương thức để thêm hợp đồng
    private static void themHopDong(QuanLyPhongTro quanLyPhongTro, Scanner scanner) {
        System.out.print("Nhập mã hợp đồng: ");
        String maHopDong = scanner.nextLine();
        System.out.print("Nhập mã khách hàng: ");
        String maKH = scanner.nextLine();
        System.out.print("Nhập mã phòng: ");
        String maPhongHD = scanner.nextLine();
        System.out.print("Nhập ngày bắt đầu (YYYY-MM-DD): ");
        String ngayBatDau = scanner.nextLine();
        System.out.print("Nhập ngày kết thúc (YYYY-MM-DD): ");
        String ngayKetThuc = scanner.nextLine();
        System.out.print("Nhập tiền điện: ");
        double tienDien = scanner.nextDouble();
        System.out.print("Nhập tiền nước: ");
        double tienNuoc = scanner.nextDouble();
        scanner.nextLine(); // Đọc ký tự xuống dòng

        // Kiểm tra xem khách hàng và phòng có tồn tại không
        KhachHang khachHang = quanLyPhongTro.timKhachHang(maKH);
        Phong phong = quanLyPhongTro.timPhong(maPhongHD);

        if (khachHang != null && phong != null) {
            if (quanLyPhongTro.kiemTraPhongTonTai(maPhongHD)) {
                System.out.println("Phòng đã được đặt, xin đặt lại phòng khác.");
                return;
            }
            if (quanLyPhongTro.kiemTraHopDongTonTai(maHopDong)) {
                System.out.println("Hợp đồng đã tồn tại! Tạo hợp đồng khác.");
                return;
            }

            // Tạo hợp đồng và tính tổng tiền
            double tongTien = phong.tinhTongTien(ngayBatDau, ngayKetThuc);
            HopDong hopDong = new HopDong(maHopDong, maKH, maPhongHD, ngayBatDau, ngayKetThuc, tienDien, tienNuoc, tongTien, quanLyPhongTro);
            quanLyPhongTro.themHopDong(hopDong);
            quanLyPhongTro.themPhongDD(maPhongHD);
            System.out.println("Đã thêm hợp đồng thành công! Tổng tiền hợp đồng: " + tongTien);
        } else {
            System.out.println("Không thể thêm hợp đồng. Kiểm tra lại mã khách hàng hoặc mã phòng!");
        }
    }

    // Phương thức để sửa thông tin khách hàng
    private static void suaThongTinKhachHang(QuanLyPhongTro quanLyPhongTro, Scanner scanner) {
        System.out.print("Nhập mã khách hàng cần sửa: ");
        String maKhachHangSua = scanner.nextLine();
        System.out.print("Nhập tên mới: ");
        String tenMoi = scanner.nextLine();
        System.out.print("Nhập số điện thoại mới: ");
        String soDienThoaiMoi = scanner.nextLine();
        System.out.print("Nhập email mới: ");
        String emailMoi = scanner.nextLine();
        quanLyPhongTro.suaThongTinKhachHang(maKhachHangSua, tenMoi, soDienThoaiMoi, emailMoi);
    }
}
