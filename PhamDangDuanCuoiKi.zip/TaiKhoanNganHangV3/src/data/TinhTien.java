package data;

public interface TinhTien {
    double tinhTienPhong(); // Tính tiền phòng
    double tinhTienDienNuoc(); // Tính tiền điện, nước
}
