package data;

import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Phong implements TinhTien{
    private String maPhong;
    private String tenPhong;
    private double giaPhong;
    private double tienDien;
    private double tienNuoc;
    // Constructor


    public Phong(double tienNuoc, double tienDien, double giaPhong, String tenPhong, String maPhong) {
        this.tienNuoc = tienNuoc;
        this.tienDien = tienDien;
        this.giaPhong = giaPhong;
        this.tenPhong = tenPhong;
        this.maPhong = maPhong;
    }

    // Phương thức tính tiền phòng và chi phí theo thời gian thuê
    public double tinhTongTien(String ngayBatDau, String ngayKetThuc) {
        // Định dạng ngày theo kiểu "yyyy-MM-dd"
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Chuyển đổi từ String thành LocalDate với định dạng đã chỉ định
        LocalDate batDau = LocalDate.parse(ngayBatDau, formatter);
        LocalDate ketThuc = LocalDate.parse(ngayKetThuc, formatter);

        // Tính số ngày thuê phòng (bao gồm ngày bắt đầu)
        long soNgay = ChronoUnit.DAYS.between(batDau, ketThuc) + 1; // Thêm 1 ngày vì ChronoUnit.DAYS.between không tính ngày bắt đầu

        // Tính tổng tiền (theo công thức yêu cầu)
        double tongTien =soNgay*(tienDien + tienNuoc) + giaPhong;

        return tongTien;
    }


    // Getter methods
    public String getMaPhong() {
        return maPhong;
    }

    public String getTenPhong() {
        return tenPhong;
    }

    public double getGiaPhong() {
        return giaPhong;
    }

    public double getTienDien() {
        return tienDien;
    }

    public void setTienDien(double tienDien) {
        this.tienDien = tienDien;
    }

    public double getTienNuoc() {
        return tienNuoc;
    }

    public void setTienNuoc(double tienNuoc) {
        this.tienNuoc = tienNuoc;
    }

    // Phương thức trừu tượng mà các lớp con phải triển khai
    @Override
    public double tinhTienPhong() {
        return 0;
    }

    @Override
    public double tinhTienDienNuoc() {
        return 0;
    }

    // Phương thức để hiển thị thông tin phòng
    public void hienThiThongTin() {
        System.out.println("Phòng - Mã: " + maPhong + ", Tên: " + tenPhong + ", Giá: " + giaPhong);
    }
}
