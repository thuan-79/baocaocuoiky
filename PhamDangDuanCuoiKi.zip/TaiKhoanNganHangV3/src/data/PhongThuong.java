package data;

public class PhongThuong extends Phong {
    private String moTa;

    public PhongThuong(double tienNuoc, double tienDien, double giaPhong, String tenPhong, String maPhong, String moTa) {
        super(tienNuoc, tienDien, giaPhong, tenPhong, maPhong);
        this.moTa = moTa;
    }

    @Override
    public double tinhTienPhong() {
        return getGiaPhong(); // Giá phòng không thay đổi
    }

    @Override
    public void hienThiThongTin() {
        super.hienThiThongTin();
        System.out.println("Mô tả: " + moTa);
    }
}
