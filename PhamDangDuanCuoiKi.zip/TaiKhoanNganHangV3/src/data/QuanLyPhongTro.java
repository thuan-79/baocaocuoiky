package data;

import java.util.ArrayList;
import java.util.List;

public class QuanLyPhongTro {
    private List<Phong> danhSachPhong;
    private List<KhachHang> danhSachKhachHang;
    private List<HopDong> danhSachHopDong;
    private List<String> danhSachPhongDD;

    public QuanLyPhongTro() {
        danhSachPhong = new ArrayList<>();
        danhSachKhachHang = new ArrayList<>();
        danhSachHopDong = new ArrayList<>();
        danhSachPhongDD = new ArrayList<>();
    }

    public void themPhong(Phong phong) {
        danhSachPhong.add(phong);
    }

    public void themPhongDD(String maPhong) {
        danhSachPhongDD.add(maPhong);
    }

    public void themKhachHang(KhachHang khachHang) {
        danhSachKhachHang.add(khachHang);
    }

    public void hienThiDanhSachPhong() {
        for (Phong phong : danhSachPhong) {
            phong.hienThiThongTin();
        }
    }

    public void hienThiDanhSachKhachHang() {
        for (KhachHang khachHang : danhSachKhachHang) {
            khachHang.hienThiThongTin();
        }
    }

    // Sửa lại phương thức hiển thị hợp đồng
    public void hienThiDanhSachHopDong() {
        for (HopDong hopDong : danhSachHopDong) {
            // Hiển thị thông tin hợp đồng
            System.out.println("Hợp Đồng - Mã: " + hopDong.getMaHopDong() + ", Mã Khách Hàng: " + hopDong.getMaKhachHang() +
                    ", Mã Phòng: " + hopDong.getMaPhong() + ", Ngày Bắt Đầu: " + hopDong.getNgayBatDau() +
                    ", Ngày Kết Thúc: " + hopDong.getNgayKetThuc() + ", Tiền Điện: " + hopDong.getTienDien() +
                    ", Tiền Nước: " + hopDong.getTienNuoc() + ", Tổng Tiền: " + hopDong.getTongTien());

            // Lấy khách hàng từ mã khách hàng trong hợp đồng
            KhachHang khachHang = timKhachHang(hopDong.getMaKhachHang());
            if (khachHang != null) {
                // Hiển thị thông tin khách hàng
                System.out.println("Khách Hàng: " + khachHang.getTenKhachHang() +
                        ", SĐT: " + khachHang.getSoDienThoai() + ", Email: " + khachHang.getEmail());
            } else {
                System.out.println("Không tìm thấy thông tin khách hàng.");
            }
        }
    }

    public void xoaHD(String maHD) {
        danhSachHopDong.removeIf(hopDong -> hopDong.getMaHopDong().equals(maHD));
    }

    public void xoaPhong(String maPhong) {
        danhSachPhong.removeIf(Phong -> Phong.getMaPhong().equals(maPhong));
    }

    public boolean kiemTraKhachHangTonTai(String maKhachHang) {
        for (KhachHang khachHang : danhSachKhachHang) {
            if (khachHang.getMaKhachHang().equals(maKhachHang)) {
                return true; // Khách hàng tồn tại
            }
        }
        return false; // Khách hàng không tồn tại
    }

    public boolean kiemTraPhongTonTai(String maPhong) {
        for (String phong : danhSachPhongDD) {
            if (phong.equals(maPhong)) {
                return true;
            }
        }
        return false;
    }

    public boolean kiemTraHopDongTonTai(String maHD) {
        for (HopDong hopDong : danhSachHopDong) {
            if (hopDong.getMaHopDong().equals(maHD)) {
                return true;
            }
        }
        return false;
    }

    public boolean themHopDong(HopDong hopDong) {
        if (kiemTraKhachHangTonTai(hopDong.getMaKhachHang())) {
            danhSachHopDong.add(hopDong);
            return true; // Thêm hợp đồng thành công
        } else {
            System.out.println("Lỗi: Khách hàng với mã " + hopDong.getMaKhachHang() + " không tồn tại.");
            return false; // Thêm hợp đồng thất bại
        }
    }

    // Phương thức tìm khách hàng theo mã
    public KhachHang timKhachHang(String maKhachHang) {
        for (KhachHang kh : danhSachKhachHang) {
            if (kh.getMaKhachHang().equals(maKhachHang)) {
                return kh;
            }
        }
        return null;  // Trả về null nếu không tìm thấy khách hàng
    }

    // Phương thức tìm phòng theo mã
    public Phong timPhong(String maPhong) {
        for (Phong p : danhSachPhong) {
            if (p.getMaPhong().equals(maPhong)) {
                return p;
            }
        }
        return null;  // Trả về null nếu không tìm thấy phòng
    }

    // Phương thức sửa thông tin khách hàng
    public void suaThongTinKhachHang(String maKhachHang, String tenMoi, String soDienThoaiMoi, String emailMoi) {
        KhachHang khachHang = timKhachHang(maKhachHang);
        if (khachHang != null) {
            // Cập nhật thông tin khách hàng
            khachHang.setTenKhachHang(tenMoi);
            khachHang.setSoDienThoai(soDienThoaiMoi);
            khachHang.setEmail(emailMoi);
            System.out.println("Thông tin khách hàng đã được cập nhật!");
        } else {
            System.out.println("Không tìm thấy khách hàng với mã: " + maKhachHang);
        }
    }

    // Phương thức kiểm tra khách hàng có hợp đồng không
    public boolean khachHangCoHopDong(String maKhachHang) {
        for (HopDong hopDong : danhSachHopDong) {
            if (hopDong.getMaKhachHang().equals(maKhachHang)) {
                return true; // Nếu có hợp đồng với khách hàng này
            }
        }
        return false; // Không có hợp đồng nào với khách hàng
    }
}
