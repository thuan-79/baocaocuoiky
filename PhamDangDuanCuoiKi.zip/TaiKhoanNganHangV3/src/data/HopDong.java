package data;

public class HopDong {
    private String maHopDong;
    private String maKhachHang;
    private String maPhong;
    private String ngayBatDau;
    private String ngayKetThuc;
    private double tienDien;
    private double tienNuoc;
    private double tongTien;
    private QuanLyPhongTro quanLyPhongTro;

    public HopDong(String maHopDong, String maKhachHang, String maPhong, String ngayBatDau, String ngayKetThuc, double tienDien, double tienNuoc,double tongTien, QuanLyPhongTro quanLyPhongTro) {
        this.maHopDong = maHopDong;
        this.maKhachHang = maKhachHang;
        this.maPhong = maPhong;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.tienDien = tienDien;
        this.tienNuoc = tienNuoc;
        this.quanLyPhongTro = quanLyPhongTro;
        this.tongTien = tongTien;
    }

    public String getMaHopDong() {
        return maHopDong;
    }

    public void setMaHopDong(String maHopDong) {
        this.maHopDong = maHopDong;
    }

    public String getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(String maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) {
        this.maPhong = maPhong;
    }

    public String getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(String ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public String getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(String ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public double getTienDien() {
        return tienDien;
    }

    public void setTienDien(double tienDien) {
        this.tienDien = tienDien;
    }

    public double getTienNuoc() {
        return tienNuoc;
    }

    public void setTienNuoc(double tienNuoc) {
        this.tienNuoc = tienNuoc;
    }

    public double getTongTien() {
        return tongTien;
    }

    public void setTongTien(double tongTien) {
        this.tongTien = tongTien;
    }

    public QuanLyPhongTro getQuanLyPhongTro() {
        return quanLyPhongTro;
    }

    public void setQuanLyPhongTro(QuanLyPhongTro quanLyPhongTro) {
        this.quanLyPhongTro = quanLyPhongTro;
    }

    private double tinhTongTien() {
        Phong phong = quanLyPhongTro.timPhong(maPhong);
        if (phong != null) {
            return phong.tinhTienPhong() ;

        }
        return 0;
    }

    public void hienThiThongTin() {
        System.out.println("Hợp Đồng - Mã: " + maHopDong + ", Mã Khách Hàng: " + maKhachHang + ", Mã Phòng: " + maPhong +
                ", Ngày Bắt Đầu: " + ngayBatDau + ", Ngày Kết Thúc: " + ngayKetThuc +
                ", Tiền Điện: " + tienDien + ", Tiền Nước: " + tienNuoc + ", Tổng Tiền: " + tongTien);
    }
}
