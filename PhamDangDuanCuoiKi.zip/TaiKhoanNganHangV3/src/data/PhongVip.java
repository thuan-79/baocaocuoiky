package data;

public class PhongVip extends Phong {
    private String loaiPhong;

    // Constructor


    public PhongVip(double tienNuoc, double tienDien, double giaPhong, String tenPhong, String maPhong, String loaiPhong) {
        super(tienNuoc, tienDien, giaPhong, tenPhong, maPhong);
        this.loaiPhong = loaiPhong;
    }

    @Override
    public double tinhTienPhong() {
        // Tính tiền phòng cho Phòng Vip (giả sử có thêm phí điện)
        return getGiaPhong() + getTienDien();  // Tổng tiền phòng bao gồm tiền điện
    }

    @Override
    public void hienThiThongTin() {
        super.hienThiThongTin(); // Gọi phương thức hiển thị thông tin của lớp cha
        System.out.println("Loại phòng: " + loaiPhong);
    }
}
